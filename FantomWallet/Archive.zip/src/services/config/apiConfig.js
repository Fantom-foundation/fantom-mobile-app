export default {
    development: {
        auth0: {
            apiUrl: '',
            scope: '',
            client_id: '',
            connection: '',
        },
        core: {
            apiUrl: 'https://jsonplaceholder.typicode.com/',
            key: '',
        },
    },
    production: {
        auth0: {
            apiUrl: '',
            scope: '',
            client_id: '',
            connection: '',
        },
        core: {
            apiUrl: 'https://jsonplaceholder.typicode.com/',
            key: '',
        },
    },
};
