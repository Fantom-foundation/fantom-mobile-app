export const COUNTER_INCREMENT = 'counter_increment';
export const COUNTER_DECREMENT = 'counter_decrement';