const _model = {
    userId: undefined,
    id: undefined,
    title: '',
    completed: false,
};

const model = _model;

export default model;
