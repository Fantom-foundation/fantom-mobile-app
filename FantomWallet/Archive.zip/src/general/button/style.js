const style = {
    buttonStyle:{
        backgroundColor: 'rgb(63,108,175)',
        padding: 20,
        height: 60,
        width: '100%',
        justifyContent: 'center', 
        alignItems: 'center',
          
    },
    textStyle: {
        color: '#fff',
        fontSize: 20,
        // fontFamily: 'Times New Roman',
        fontWeight: 'bold',
    }
}
export default style;