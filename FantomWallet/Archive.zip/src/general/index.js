import LinkButton_ from './linkButton/';

export const LinkButton = LinkButton_;