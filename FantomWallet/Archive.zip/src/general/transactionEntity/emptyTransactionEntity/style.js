const style = {
    mainViewStyle: {
        flex: 1,
        margin: 50,
        alignItems: 'center',
    },
    headingInfoStyle: {
        margin: 4,
        fontSize: 20,
        fontWeight: 'bold',
    },
}

export default style;