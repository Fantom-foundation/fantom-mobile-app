const styles = {
    text: {
        textDecorationLine: 'underline',
        color: '#8064a2'
    },
}
export default styles;