
const style = {
    mainContainerStyle: {
        flex: 1,
    },
    footerStyle: {
        position: 'absolute',
        bottom: 0,
        flexDirection: 'row',
    },
}

export default style;