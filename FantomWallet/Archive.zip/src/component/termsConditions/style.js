const style = {
    mainContainerStyle: {
        flex: 1,
    },
    statusBarStyle: {
        height: 20,
    },
    footerStyle: {
        position: 'absolute',
        bottom: 0,
        flexDirection: 'row',
    },
}

export default style;