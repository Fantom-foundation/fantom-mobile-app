const style = {
    withdrawViewStyle: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f8f8f8',
    },
    textViewStyle: {
        // fontFamily: 'Times New Roman',
    }
}
export default style;