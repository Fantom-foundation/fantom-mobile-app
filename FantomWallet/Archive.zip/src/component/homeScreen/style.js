const style = {
    mainContainerStyle: {
        flex: 1,
        backgroundColor:'green'
    },
    footerStyle: {
        backgroundColor: 'orange',
        position: 'absolute',
        bottom: 0,
        flexDirection: 'row',
        padding: 4,
    },
}

export default style;