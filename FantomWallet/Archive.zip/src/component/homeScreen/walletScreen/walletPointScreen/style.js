const style = {
    pointViewStyle: {
        flex: 1,
        backgroundColor: '#f8f8f8',
    },
    textViewStyle: {
        // fontFamily: 'Times New Roman',
    }
}
export default style;