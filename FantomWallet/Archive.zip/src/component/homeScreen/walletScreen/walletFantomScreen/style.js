const style = {
    fantomViewStyle: {
        flex: 1,
        backgroundColor: 'white',
    },
    textViewStyle: {
        // fontFamily: 'Times New Roman',
    }
}
export default style;